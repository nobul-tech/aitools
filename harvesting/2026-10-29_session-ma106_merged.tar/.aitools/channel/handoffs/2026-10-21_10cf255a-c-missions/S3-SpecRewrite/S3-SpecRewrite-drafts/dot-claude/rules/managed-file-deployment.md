---
paths:
  - scripts/**
  - deploy/**
  - shared/**
---

## Managed File Deployment (this repo)

All setup scripts that deploy files to user directories must follow the
deployment type matching the file format. Every type has the same
correctness requirements: backup, logging, and validation. They differ
only in merge strategy.

### Deployment types

| Type | Merge strategy | Files |
|------|---------------|-------|
| Markdown | Interactive diff review via `deploy_managed_file` (SOURCE is the source of truth; one menu: overwrite / accept & adopt / merge & adopt / skip / abort) | CLAUDE.md, `~/.claude/rules/*.md`, skill SKILL.md files |
| JSON config | Read-then-merge on managed fields. Profile-sourced fields (settings.json) use granular field-level review (`sync_managed_json` / `Sync-ManagedJson`: auto-adopt when profile silent, per-leaf overwrite/adopt/skip/abort on divergence); harness-managed keys (e.g. `hooks`) reconcile silently. JSON deployed through `deploy_managed_file` is reviewed field by field with SOURCE owning every field (`review_json_fields` / `Review-JsonFields`; no merge) | settings.json, cli-config.json, mcp.json, deployed JSON |
| Shell script | Interactive diff review via `deploy_managed_file` (same menu as markdown) | Hook scripts (`~/.claude/hooks/*.sh`) |

`deploy_managed_file()` / `Deploy-ManagedFile` is defined in
`@scripts/aitools-lib.sh` / `@scripts/aitools-lib.ps1`.
Full state machine spec: `@reference/managed-file-deployment.md`.
Choices and failure handling: `@.claude/rules/agentic-standards.md`
"Managed-file review choices and merge". There is no ancestor and no deploy
state.

**Adopt target.** Callers pass the absolute path of the repo file the
content came from (`ADOPT_PATH` / `-AdoptPath`, `""` for none). On accept &
adopt or merge & adopt the library writes that file itself, in the same
step. Callers never copy files back. Adopt and merge write the working tree
only: neither the library nor a caller commits or pushes. Exception until
decided (S3-SpecRewrite Q1): CLAUDE.md adopts through its template
transform (`adopt_claude_md`).

### Content sources

Deployed content originates from two repos:

| Source | Priority | What it provides |
|--------|----------|-----------------|
| Dotprofile repo (`aitools-<username>`) | Primary (wins if present) | CLAUDE.md template, user rules, profile.json (preferences, identity, machine profiles) |
| aitools repo (`shared/`) | Fallback | claude-shared.md template, hook scripts, skills, shell aliases |

- **Template interpolation**: `{{PLACEHOLDER}}` tokens in CLAUDE.md replaced with `profile.json` values at deploy time
- **Machine profile selection**: `config.json` `machineAlias` → `profile.json` `profiles[alias]`. Fallback: hostname match, then first profile
- **Rules**: additive deploy from `<userRepoPath>/claude/rules/` — managed files updated, unmanaged files in target preserved
- **Skills**: vendored from upstream in `shared/skills/`, deployed to `~/.claude/skills/` and `~/.cursor/skills/`
- **Hooks**: canonical source in `shared/hooks/`, deployed to `~/.claude/hooks/`

Full spec: `@reference/user-repo.md`

### Shared requirements (all types)

These apply equally regardless of file type:

1. **Backup before write**: call `backup_file` / `Backup-File` before
   writing to an existing file. For markdown and shell script types and
   deployed JSON, `deploy_managed_file` handles this internally, for LOCAL
   and for the adopt target, and restores the backups when a write, merge or
   validation fails. For the other JSON config writers, the caller MUST call
   it explicitly.
2. **Diff logging**: log what changed to deploy.log before writing.
   Markdown/shell: handled by `deploy_managed_file`. JSON config: log
   changed fields with old → new values.
3. **Post-write validation**: verify the written file immediately.
   JSON: valid parse + required keys. Markdown: non-empty + required
   sections. Shell: non-empty + executable bit.
4. **Outcome tracking**: every deployment must resolve to
   created, updated, or unchanged — and report via `write_summary`.
   `deploy_managed_file` results (created, updated, verified, accept &
   adopt, skipped, failed) are recorded with the deploy tracker; `failed`
   is an ERROR row and the run continues with the next file.

### Platform-specific config values

JSON config files may contain values that differ by platform, and a few
by environment. OS guards in setup scripts ensure the correct platform
variant is deployed; the environment API selects environment variants.
Examples:

| Config | Field | Windows | macOS | Linux |
|--------|-------|---------|-------|-------|
| mcp.json | chrome-devtools command | `cmd /c npx -y chrome-devtools-mcp@latest --isolated` | `npx -y chrome-devtools-mcp@latest --isolated` | same as macOS |
| mcp.json, ~/.claude.json | chrome-devtools command, Claude Code web environment (D-CHR2) | n/a | n/a | `npx -y chrome-devtools-mcp@latest --isolated --headless --chromeArg=--no-sandbox` |
| settings.json | hook paths | `bash "C:/Users/.../hooks/session-archive.sh"` | `bash "/Users/.../hooks/session-archive.sh"` | `bash "/home/.../hooks/session-archive.sh"` (`/root/...` as root) |

Scripts must NEVER write cross-platform values (e.g., macOS paths on
Windows) or another environment's values. The OS guard + platform
dispatch pattern and the environment API prevent this — see
`@.claude/rules/cross-platform.md` "Environment branches".

### Updating this table

Adding a row (new file type) or column (new attribute) requires updating:
this rule, `@reference/managed-file-deployment.md`,
`@.cursor/rules/managed-file-deployment.mdc`, and
the `/incident` skill if there are implementation gaps. See
`@.claude/rules/tool-lifecycle.md` "Deployment pattern updates".

### Cross-references

- State machine + detail: `@reference/managed-file-deployment.md`
- Text + JSON menus: `@.claude/rules/interactive-menus.md`
- JSON write safety: `@.claude/rules/config-file-safety.md`
- AI merge: `@.claude/rules/agentic-standards.md`
- Content sources: `@reference/user-repo.md`
- Known incidents: `/incident` skill
