# check-lib.sh -- shared library for check-pre-commit/pre-push/post-push scripts
# Sourced, not executed directly. No shebang, no set -euo pipefail (caller sets it).

# Source base lib (provides IS_MACOS, IS_WINDOWS, AITOOLS_LOG_DIR, read_config_key, display_path,
# resolve_user_repo_path)
_CHECK_LIB_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$_CHECK_LIB_DIR/aitools-lib.sh"

# ---------------------------------------------------------------------------
# Colors (disabled if not a terminal)
# ---------------------------------------------------------------------------
if [ -t 1 ]; then
    RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[0;33m'
    DIM='\033[0;90m'; BOLD='\033[1m'; RESET='\033[0m'
else
    RED=''; GREEN=''; YELLOW=''; DIM=''; BOLD=''; RESET=''
fi

# ---------------------------------------------------------------------------
# Counters
# ---------------------------------------------------------------------------
PASS_COUNT=0
FAIL_COUNT=0
WARN_COUNT=0
SKIP_COUNT=0

# ---------------------------------------------------------------------------
# File logging (checks.log + checks.jsonl)
# ---------------------------------------------------------------------------
# Log path: same directory as setup scripts (deploy.log)
_CHECK_LOG_DIR=""
_CHECK_LOG=""
_CHECK_JSONL=""
_CHECK_NAME=""

check_log_init() {
    _CHECK_NAME="${1:?check_log_init requires a check name}"
    # Log directory from base lib (AITOOLS_LOG_DIR)
    _CHECK_LOG_DIR="$AITOOLS_LOG_DIR"
    _CHECK_LOG="$_CHECK_LOG_DIR/checks.log"
    _CHECK_JSONL="$_CHECK_LOG_DIR/checks.jsonl"
    mkdir -p "$_CHECK_LOG_DIR"
    _rotate_log "$_CHECK_LOG"
    _rotate_log "$_CHECK_JSONL"

    local ts
    ts=$(date -u +%Y-%m-%dT%H:%M:%SZ)
    local host
    host=$(hostname -s 2>/dev/null || hostname)
    local os_name
    case "$(uname -s)" in
        Darwin*) os_name="macOS" ;;
        *)       os_name="$(uname -s)" ;;
    esac

    printf '[%s] [%s] === RUN START ===\n' "$ts" "$_CHECK_NAME" >> "$_CHECK_LOG"
    printf '{"ts":"%s","check":"%s","event":"run_start","host":"%s","os":"%s"}\n' \
        "$ts" "$_CHECK_NAME" "$host" "$os_name" >> "$_CHECK_JSONL"

    # Bridge: initialize aitools-lib logging vars so lib functions
    # (log, ensure_tool_on_path, deploy_managed_file, etc.) work in check context.
    # Operational messages go to deploy.log alongside setup script output.
    SCRIPT_NAME="$_CHECK_NAME"
    LOG_DIR="$_CHECK_LOG_DIR"
    LOG_FILE="$_CHECK_LOG_DIR/deploy.log"
    ERRORS=0
    WARNINGS=0
}

# Internal: log one step result to both files
_check_log_step() {
    [ -z "$_CHECK_LOG" ] && return 0
    local num="$1" label="$2" result="$3" detail="${4:-}"
    local ts
    ts=$(date -u +%Y-%m-%dT%H:%M:%SZ)
    printf '[%s] [%s] %3s. %-42s [%s]' "$ts" "$_CHECK_NAME" "$num" "$label" "$result" >> "$_CHECK_LOG"
    [ -n "$detail" ] && printf ' %s' "$detail" >> "$_CHECK_LOG"
    printf '\n' >> "$_CHECK_LOG"
    # Escape detail for JSON (backslashes and double quotes)
    local json_detail
    json_detail=$(printf '%s' "$detail" | sed 's/\\/\\\\/g; s/"/\\"/g')
    printf '{"ts":"%s","check":"%s","step":"%s","label":"%s","result":"%s","detail":"%s"}\n' \
        "$ts" "$_CHECK_NAME" "$num" "$label" "$result" "$json_detail" >> "$_CHECK_JSONL"
}

# ---------------------------------------------------------------------------
# Step formatters
# ---------------------------------------------------------------------------
# Usage: step_pass "1" "Git identity" ["optional detail"]
step_pass() {
    local num="$1" label="$2" detail="${3:-}"
    printf "%3s. %-42s ${GREEN}[PASS]${RESET}" "$num" "$label"
    [ -n "$detail" ] && printf " %s" "$detail"
    printf "\n"
    PASS_COUNT=$((PASS_COUNT + 1))
    _check_log_step "$num" "$label" "PASS" "$detail"
}

step_fail() {
    local num="$1" label="$2" detail="${3:-}"
    printf "%3s. %-42s ${RED}[FAIL]${RESET}" "$num" "$label"
    [ -n "$detail" ] && printf " %s" "$detail"
    printf "\n"
    FAIL_COUNT=$((FAIL_COUNT + 1))
    _check_log_step "$num" "$label" "FAIL" "$detail"
}

step_warn() {
    local num="$1" label="$2" detail="${3:-}"
    printf "%3s. %-42s ${YELLOW}[WARN]${RESET}" "$num" "$label"
    [ -n "$detail" ] && printf " %s" "$detail"
    printf "\n"
    WARN_COUNT=$((WARN_COUNT + 1))
    _check_log_step "$num" "$label" "WARN" "$detail"
}

step_skip() {
    local num="$1" label="$2" detail="${3:-}"
    printf "%3s. %-42s ${DIM}[SKIP]${RESET}" "$num" "$label"
    [ -n "$detail" ] && printf " %s" "$detail"
    printf "\n"
    SKIP_COUNT=$((SKIP_COUNT + 1))
    _check_log_step "$num" "$label" "SKIP" "$detail"
}

# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------
print_summary() {
    echo ""
    printf "=== SUMMARY: ${GREEN}%d PASS${RESET}, ${DIM}%d SKIP${RESET}, ${YELLOW}%d WARN${RESET}, ${RED}%d FAIL${RESET} ===\n" \
        "$PASS_COUNT" "$SKIP_COUNT" "$WARN_COUNT" "$FAIL_COUNT"
    # Log summary to files
    if [ -n "$_CHECK_LOG" ]; then
        local ts
        ts=$(date -u +%Y-%m-%dT%H:%M:%SZ)
        printf '[%s] [%s] === SUMMARY: %d PASS, %d SKIP, %d WARN, %d FAIL ===\n' \
            "$ts" "$_CHECK_NAME" "$PASS_COUNT" "$SKIP_COUNT" "$WARN_COUNT" "$FAIL_COUNT" >> "$_CHECK_LOG"
        printf '{"ts":"%s","check":"%s","event":"run_end","pass":%d,"skip":%d,"warn":%d,"fail":%d}\n' \
            "$ts" "$_CHECK_NAME" "$PASS_COUNT" "$SKIP_COUNT" "$WARN_COUNT" "$FAIL_COUNT" >> "$_CHECK_JSONL"
    fi
}

# read_config_key is provided by aitools-lib.sh

# ---------------------------------------------------------------------------
# Repo root and config resolution
# ---------------------------------------------------------------------------
# REPO_ROOT must be set by the sourcing script (via BASH_SOURCE or similar).
# This library does NOT set it -- the caller knows its own location.

# resolve_config -- sets CONFIG_FILE (the config.json path; check-pre-push step 7
# copies it) and USER_REPO_PATH (the dotprofile), taken from the lib's one resolver
# (resolve_user_repo_path in aitools-lib.sh; order: aitools-profile.sh
# resolve_user_repo), so a check sees the same dotprofile as the setup scripts.
# USER_REPO_VIA says how it was found (env|config|convention|scan|none):
# ait-harvest.py reads only config.json, so a check about archiving must not
# treat a non-config answer as "archiving works" (check-post-push step 5).
# Called before check_log_init: the resolver's lines go to deploy.log under the
# init-logging name (bridge pattern, reference/script-standards-detail.md).
# rc 1 (no dotprofile, shared-only mode) is not an error in a check: USER_REPO_PATH
# stays empty and callers skip their dotprofile steps ([ -n ] before use).
# rc 3 was already logged by the lib (log_error, ERROR row when a run summary
# exists); USER_REPO_PATH stays empty, so those steps skip too.
resolve_config() {
    CONFIG_FILE="$HOME/.aitools/config.json"
    USER_REPO_PATH=""
    USER_REPO_VIA="none"
    local rc=0
    resolve_user_repo_path || rc=$?
    USER_REPO_PATH="$AITLIB_USER_REPO_PATH"
    USER_REPO_VIA="${AITLIB_USER_REPO_VIA:-none}"
    if [ "$rc" -ne 0 ] && [ "$rc" -ne 1 ]; then
        log "dotprofile unresolved (resolver error above) -- dotprofile steps skip as 'not configured'"
    fi
}

# Platform detection (IS_MACOS, IS_WINDOWS) provided by aitools-lib.sh

# ---------------------------------------------------------------------------
# Cross-platform file mtime (epoch seconds)
# ---------------------------------------------------------------------------
get_mtime() {
    local file="$1"
    # stat fails only if the file vanished; 0 (epoch) makes it read as oldest, so
    # check-post-push never picks it as "newest" and flags it stale (conservative).
    if $IS_MACOS; then
        stat -f %m "$file" 2>/dev/null || echo 0
    else
        stat -c %Y "$file" 2>/dev/null || echo 0
    fi
}

# ---------------------------------------------------------------------------
# pwsh check
# ---------------------------------------------------------------------------
require_pwsh() {
    local step_num="$1" step_label="$2"
    if ! command -v pwsh &>/dev/null; then
        step_fail "$step_num" "$step_label" "pwsh not found -- install: brew install powershell/tap/powershell"
        return 1
    fi
    return 0
}
