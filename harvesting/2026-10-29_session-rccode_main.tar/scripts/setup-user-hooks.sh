#!/usr/bin/env bash
# setup-user-hooks.sh — Deploys Claude Code hooks to ~/.claude/settings.json
# Safe to re-run — merges the `hooks` key without clobbering existing settings.
#
# Hook deployment + registration are GENERATED from shared/hooks/hooks-manifest.json
# (the single source of truth). Adding a hook = one manifest entry; no edits to this
# script. This closes the recurring "deployed but not registered" / parallel-list-drift
# incident class (RCA: .scratch investigation 2026-06-20; issue #7 / plan §5).
#
# Managed fields: hooks.SessionEnd, hooks.SessionStart, hooks.PreToolUse, hooks.PostToolUse, hooks.Stop
# Preserved: permissions, enabledPlugins, all other fields
#
# Claude preferences (autoMemoryEnabled/alwaysThinkingEnabled/effortLevel) and all
# other non-hook settings are profile-sourced and synced by setup-user-settings.
# See reference/user-repo.md, shared/hooks/hooks-manifest.json, and shared/hooks/ for details.

# --- BEGIN hooks body (extracted by build-deploy) ---
set -euo pipefail

# --- Flag parsing ---
DRY_RUN=false
FORCE=false
for arg in "$@"; do
    case "$arg" in
        --dry-run) DRY_RUN=true ;;
        --force)   FORCE=true ;;
    esac
done
[ "${AITOOLS_DRY_RUN:-}" = "1" ] && DRY_RUN=true

# --- Shared library ---
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/aitools-lib.sh"
logging_init "setup-user-hooks"

# --- OS guard ---
case "$(uname -s)" in
    MINGW*|MSYS*|CYGWIN*)
        log_error "This script is for macOS/Linux. On Windows, use ${SCRIPT_NAME}.ps1 instead."
        exit 1 ;;
esac

[ "$DRY_RUN" = "true" ] && log "[DRY RUN] Preview mode -- no files will be written"

# --- Require node for JSON manipulation ---
if ! command -v node &>/dev/null; then
    log_error "node required for JSON manipulation"
    write_summary ERROR "claude hooks" "node not found"
    exit 1
fi

# --- BEGIN hook deployment (replaced by build-deploy) ---
# --- Resolve repo path + manifest ---
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

# Manifest = single source of truth for which hooks exist + how they register.
MANIFEST="$REPO_DIR/shared/hooks/hooks-manifest.json"
if [ ! -f "$MANIFEST" ]; then
    log_error "Hook manifest not found: $MANIFEST"
    write_summary ERROR "claude hooks" "hook manifest not found"
    exit 1
fi

# User repo: home of user-created (non-manifest) hooks only (SD-2, incident #80).
# Manifest hooks have one version, in shared/hooks; a dotprofile copy is never
# deployed (it would freeze the hook on this machine and diverge from the MDM
# path, which embeds shared/hooks only).
# `|| true`: key is absent until 'aitools user init' runs; without the guard,
# set -e silently aborts. An empty result is handled below (no dotprofile).
USER_REPO_PATH=$(read_config_key "$HOME/.aitools/config.json" "userRepoPath") || true
DOTPROFILE_HOOKS=""
if [ -n "$USER_REPO_PATH" ] && [ -d "$USER_REPO_PATH/claude/hooks" ]; then
    DOTPROFILE_HOOKS="$USER_REPO_PATH/claude/hooks"
fi

# Resolve hook source: shared/hooks, then scripts/ (for deploy-only .py helpers
# like ait-harvest.py that live in scripts/). Same order as build-deploy.sh's
# embed loops, so the dev and MDM paths deploy the same file.
resolve_hook() {
    local hook_name="$1"
    if [ -f "$REPO_DIR/shared/hooks/$hook_name" ]; then
        printf '%s\n' "$REPO_DIR/shared/hooks/$hook_name"
    elif [ -f "$REPO_DIR/scripts/$hook_name" ]; then
        printf '%s\n' "$REPO_DIR/scripts/$hook_name"
    else
        printf '%s\n' "$REPO_DIR/shared/hooks/$hook_name"
    fi
}

# Files to deploy = registered hooks + deploy-only helpers, from the manifest.
HOOK_FILES=()
while IFS= read -r _f; do
    [ -n "$_f" ] && HOOK_FILES+=("$_f")
done < <(node -e '
const fs = require("fs");
const m = JSON.parse(fs.readFileSync(process.argv[1], "utf8"));
const files = [...m.hooks.map(h => h.file), ...((m.deploy) || [])];
console.log(files.join("\n"));
' "$MANIFEST")

if [ "${#HOOK_FILES[@]}" -eq 0 ]; then
    log_error "Manifest produced no hook files -- aborting"
    write_summary ERROR "claude hooks" "manifest lists no hooks"
    exit 1
fi

# Registration list (event/file/matcher) from the manifest -- passed to the node
# merge block as an argv. build-deploy embeds this statically for the
# self-contained MDM path, so the node block is identical dev and deploy.
# The exit code is captured (a bare assignment would abort under set -e with no row).
regs_rc=0
REGS_JSON=$(node -e '
const fs = require("fs");
const m = JSON.parse(fs.readFileSync(process.argv[1], "utf8"));
console.log(JSON.stringify(m.hooks.map(h => ({event: h.event, file: h.file, matcher: h.matcher || ""}))));
' "$MANIFEST") || regs_rc=$?
if [ "$regs_rc" -ne 0 ] || [ -z "$REGS_JSON" ]; then
    log_error "Failed to build registration list from manifest (node exit $regs_rc)"
    write_summary ERROR "claude hooks" "registration list failed"
    exit 1
fi

# Existence check (resolve every manifest file before deploying any).
for hook_name in "${HOOK_FILES[@]}"; do
    src=$(resolve_hook "$hook_name")
    if [ ! -f "$src" ]; then
        log_error "Hook script not found: $src"
        write_summary ERROR "claude hooks" "hook script missing: $hook_name"
        exit 1
    fi
    # A dotprofile copy of a manifest hook is ignored (SD-2): say so, so the
    # user can delete it instead of believing their edit is live.
    if [ -n "$DOTPROFILE_HOOKS" ] && [ -f "$DOTPROFILE_HOOKS/$hook_name" ]; then
        log_warn "Ignoring dotprofile copy of managed hook $hook_name ($(display_path "$DOTPROFILE_HOOKS/$hook_name")): shared/hooks is the only source -- delete the copy"
        write_summary WARN "claude hooks" "dotprofile copy ignored"
    fi
done

# Adopt target for manifest hooks: the file the hook is deployed from --
# shared/hooks/<name>, or scripts/<name> for deploy-only helpers (resolve_hook).
# Never the dotprofile (SD-2, incident #80). The library writes it.


HOOKS_CHANGED=false

if [ "$DRY_RUN" = "true" ]; then
    for hook_name in "${HOOK_FILES[@]}"; do
        src=$(resolve_hook "$hook_name")
        log "[DRY RUN] Would deploy hook: $(display_path "$src") -> $(display_path "$HOME/.claude/hooks/$hook_name")"
    done
    # Stale hook cleanup preview
    for stale_hook in surfacing-duty-stop.sh estimate-refresh-stop.sh intent-sentinel-stop.sh; do
        if [ -f "$HOME/.claude/hooks/$stale_hook" ]; then
            log "[DRY RUN] Would remove stale hook: $stale_hook"
        fi
    done
else
    mkdir -p "$HOME/.claude/hooks"

    deploy_tracker_init

    for hook_name in "${HOOK_FILES[@]}"; do
        hook_src=$(resolve_hook "$hook_name")
        hook_dst="$HOME/.claude/hooks/$hook_name"

        deploy_managed_file "$(cat "$hook_src")" "$hook_dst" "claude hooks" "$hook_name" "$hook_src"

        case "$MANAGED_FILE_RESULT" in
            created|updated|"accept & adopt")
                # accept & adopt: the library also wrote the source file in the
                # repo; a merge rewrote the deployed hook, so keep it executable.
                if ! chmod +x "$hook_dst"; then
                    log_error "Failed: $hook_name: chmod +x $(display_path "$hook_dst")"
                    write_summary ERROR "claude hooks" "chmod failed: $hook_name"
                fi
                HOOKS_CHANGED=true
                ;;
            skipped|verified|failed)
                # The tracker records the outcome (failed -> ERROR row).
                ;;
        esac
        deploy_tracker_record "$MANAGED_FILE_RESULT" "claude hooks" "$hook_name"
    done

    deploy_tracker_summary "claude hooks"

    # --- Stale hook cleanup ---
    # Remove hook files previously deployed but no longer managed (deleted from
    # shared/hooks/ in commit e070043). Registration cleanup is handled in the
    # node merge block via removeHookEntry.
    STALE_HOOKS="surfacing-duty-stop.sh estimate-refresh-stop.sh intent-sentinel-stop.sh"
    for stale_hook in $STALE_HOOKS; do
        stale_path="$HOME/.claude/hooks/$stale_hook"
        if [ -f "$stale_path" ]; then
            rm -f "$stale_path"
            log_ok "Removed stale hook: $stale_hook"
            HOOKS_CHANGED=true
        fi
        for bak in "$HOME/.claude/hooks/${stale_hook}.bak."*; do
            if [ -f "$bak" ]; then
                rm -f "$bak"
                log "Removed stale backup: $(basename "$bak")"
            fi
        done
    done

    # --- Reverse discovery ---
    # Scan deployed hooks for user-created hooks not in shared or dotprofile.
    for hook_file in "$HOME/.claude/hooks"/*.sh; do
        [ -f "$hook_file" ] || continue
        hook_name=$(basename "$hook_file")

        [ -f "$REPO_DIR/shared/hooks/$hook_name" ] && continue
        if [ -n "$DOTPROFILE_HOOKS" ] && [ -f "$DOTPROFILE_HOOKS/$hook_name" ]; then
            continue
        fi

        if [ -n "$USER_REPO_PATH" ]; then
            log "Found user-created hook: $hook_name"
            # tty_interactive + read_tty_choice (incident #81, GitHub #29): a
            # non-terminal stdin never prompts, and EOF at the prompt logs a
            # warning and takes the default, [s]kip -- the choice that writes
            # nothing (this menu has no overwrite option).
            if tty_interactive; then
                printf '\n  User-created hook detected: %s\n' "$hook_name" > /dev/tty
                printf '  [a]dopt to dotprofile  [s]kip\n' > /dev/tty
                printf '  > ' > /dev/tty
                choice=""
                read_tty_choice choice "skip"
                case "$choice" in
                    a|adopt)
                        # Net-new user hook -> dotprofile only (not a managed
                        # shared/ hook). Same helper for consistent backups.
                        _errors_before=$ERRORS
                        if ! adopt_managed_file "$hook_file" "$USER_REPO_PATH/claude/hooks/$hook_name" || [ "$ERRORS" -gt "$_errors_before" ]; then
                            write_summary ERROR "claude hooks" "adopt failed: $hook_name"
                        fi
                        ;;
                    *)
                        log "Skipped adoption of $hook_name"
                        ;;
                esac
            else
                log "Non-interactive: skipped adoption prompt for $hook_name"
            fi
        fi
    done
fi
# --- END hook deployment (replaced by build-deploy) ---

# --- Merge hooks + preferences into ~/.claude/settings.json ---
# Registrations are GENERATED from the manifest (event, file, matcher) -- the node
# block loops mergeHookEntry + validation over every manifest entry. No per-hook
# *_CMD vars or positional argv.
SETTINGS_FILE="$HOME/.claude/settings.json"
mkdir -p "$HOME/.claude"

# node prints diagnostics on stdout as MSG:/WARN:/DETAIL: lines (logged below) and the
# status as the first unprefixed line; its exit code is captured (validation exits 1).
merge_rc=0
MERGE_RESULT=$(node -e "
$SORT_KEYS_JS
const fs = require('fs');
const path = require('path');
const settingsFile = process.argv[1];
const regsJson = process.argv[2];
const dryRun = process.argv[3] === 'true';
const force = process.argv[4] === 'true';
const home = process.env.HOME || process.env.USERPROFILE;

// --- Registrations from the manifest (computed in bash -> REGS_JSON argv) ---
const regs = JSON.parse(regsJson).map(r => ({
    event: r.event,
    hookId: r.file,
    matcher: r.matcher || '',
    cmd: 'bash \"' + path.join(home, '.claude', 'hooks', r.file) + '\"'
}));

// Claude preferences (autoMemoryEnabled / alwaysThinkingEnabled / effortLevel)
// are NOT managed here -- they are profile-sourced and synced by
// setup-user-settings. This script manages only the \`hooks\` key.

// --- Read existing settings.json ---
let settings = {};
let corrupt = false;
try {
    settings = JSON.parse(fs.readFileSync(settingsFile, 'utf8'));
} catch (e) {
    if (e.code !== 'ENOENT') {
        corrupt = true;
        console.log('WARN: ' + settingsFile + ' is invalid JSON');
    }
}
const beforeKeys = Object.keys(settings);

// --- Merge hooks ---
if (!settings.hooks) settings.hooks = {};

// Ensure exactly one entry for a hookId in an event array (update/add/dedupe).
function mergeHookEntry(eventName, hookId, matcher, cmd, hookType) {
    hookType = hookType || 'command';
    if (!Array.isArray(settings.hooks[eventName])) settings.hooks[eventName] = [];
    const arr = settings.hooks[eventName];
    let found = false;
    for (const rule of arr) {
        if (rule.hooks && rule.hooks.some(h => h.command && h.command.includes(hookId))) {
            if (!found) {
                rule.hooks.forEach(h => {
                    if (h.command && h.command.includes(hookId)) {
                        h.command = cmd;
                        h.type = hookType;
                    }
                });
                rule.matcher = matcher;
                found = true;
            }
        }
    }
    if (!found) {
        arr.push({ matcher, hooks: [{ type: hookType, command: cmd }] });
    }
    let seen = false;
    settings.hooks[eventName] = arr.filter(rule => {
        const isMatch = rule.hooks && rule.hooks.some(h => h.command && h.command.includes(hookId));
        if (isMatch) {
            if (seen) return false;
            seen = true;
        }
        return true;
    });
}

// Remove all entries for a hookId from an event array.
function removeHookEntry(eventName, hookId) {
    if (!Array.isArray(settings.hooks[eventName])) return;
    settings.hooks[eventName] = settings.hooks[eventName].filter(rule => {
        return !(rule.hooks && rule.hooks.some(h => h.command && h.command.includes(hookId)));
    });
    if (settings.hooks[eventName].length === 0) {
        delete settings.hooks[eventName];
    }
}

// Remove stale hooks (deleted from shared/hooks/ in commit e070043).
removeHookEntry('Stop', 'surfacing-duty-stop.sh');
removeHookEntry('Stop', 'estimate-refresh-stop.sh');
removeHookEntry('Stop', 'intent-sentinel-stop.sh');

// Register every manifest hook (generated -- no hardcoded list).
for (const r of regs) mergeHookEntry(r.event, r.hookId, r.matcher, r.cmd);

// --- Clobber detection ---
const managedKeys = ['hooks'];
const afterKeys = Object.keys(settings);
const lostKeys = beforeKeys.filter(k => !afterKeys.includes(k));

if (dryRun) {
    console.log('MSG: [DRY RUN] ' + settingsFile + ': merge');
    console.log('MSG:   Managed fields: ' + managedKeys.join(', '));
    if (lostKeys.length > 0) console.log('WARN: [DRY RUN] CLOBBER: would lose: ' + lostKeys.join(', '));
    if (corrupt) console.log('WARN: [DRY RUN] File is corrupt -- --force required');
    console.log('MSG:   Registered hooks: ' + regs.length);
    console.log('dry-run');
} else if (corrupt && !force) {
    console.log('DETAIL: ' + settingsFile + ' is corrupt. Use --force to overwrite, or fix manually.');
    console.log('error-corrupt');
} else if (lostKeys.length > 0 && !force) {
    console.log('DETAIL: merge would lose fields: ' + lostKeys.join(', ') + '. Use --force to proceed.');
    console.log('error-clobber');
} else {
    if (corrupt) console.log('WARN: proceeding with --force on corrupt file');
    if (lostKeys.length > 0) console.log('WARN: proceeding with --force, losing fields: ' + lostKeys.join(', '));
    // Preserve key order on write (no sort); sortKeys is used only for the
    // order-independent unchanged comparison so reordering alone never rewrites.
    const newJson = JSON.stringify(settings, null, 2) + '\n';
    let existingJson = '';
    try { existingJson = fs.readFileSync(settingsFile, 'utf8'); } catch(e) { /* file may not exist */ }
    const existingNorm = existingJson ? JSON.stringify(sortKeys(JSON.parse(existingJson))) : '';
    const mergedNorm = JSON.stringify(sortKeys(settings));
    if (mergedNorm === existingNorm) {
        console.log('unchanged');
    } else {
        fs.writeFileSync(settingsFile, newJson);

        // Post-write validation
        const _v = JSON.parse(fs.readFileSync(settingsFile, 'utf8'));
        const _required = ['hooks'];
        const _missing = _required.filter(k => !(k in _v));
        if (_missing.length) { console.log('DETAIL: validation failed: missing ' + _missing.join(', ')); process.exit(1); }

        // Validate: every manifest hook registered exactly once (generated check).
        for (const r of regs) {
            const c = (_v.hooks[r.event] || []).filter(rule => rule.hooks && rule.hooks.some(h => h.command && h.command.includes(r.hookId))).length;
            if (c !== 1) { console.log('DETAIL: validation failed: expected 1 ' + r.event + ' ' + r.hookId + ' hook, got ' + c); process.exit(1); }
        }

        // Validate hook schema: command-type must have command field,
        // prompt-type must have prompt field (not command). (v0.60 incident guard.)
        for (const [event, rules] of Object.entries(_v.hooks || {})) {
            for (const rule of (rules || [])) {
                for (const h of (rule.hooks || [])) {
                    if (h.type === 'command' && !h.command) {
                        console.log('DETAIL: validation failed: ' + event + ' hook has type \"command\" but no command field');
                        process.exit(1);
                    }
                    if (h.type === 'prompt') {
                        if (!h.prompt) {
                            console.log('DETAIL: validation failed: ' + event + ' hook has type \"prompt\" but no prompt field.');
                            process.exit(1);
                        }
                        if (h.command) {
                            console.log('DETAIL: validation failed: ' + event + ' hook has type \"prompt\" with a command field.');
                            process.exit(1);
                        }
                    }
                }
            }
        }

        console.log('ok');
    }
}
" "$SETTINGS_FILE" "$REGS_JSON" "$DRY_RUN" "$FORCE") || merge_rc=$?

# Log node's prefixed diagnostics; the first unprefixed line is the status.
MERGE_STATUS=""
while IFS= read -r line; do
    case "$line" in
        "MSG: "*)    log "${line#MSG: }" ;;
        "WARN: "*)   log_warn "${line#WARN: }" ;;
        "DETAIL: "*) log_detail "settings-merge: ${line#DETAIL: }" ;;
        "CHANGED: "*) ;;
        *) if [ -z "$MERGE_STATUS" ]; then MERGE_STATUS="$line"; fi ;;
    esac
done <<< "$MERGE_RESULT"
# A non-zero node exit (post-write validation, uncaught error) overrides the status.
if [ "$merge_rc" -ne 0 ]; then MERGE_STATUS="error-exit"; fi

case "$MERGE_STATUS" in
    ok)
        log_ok "Hooks deployed to $(display_path "$SETTINGS_FILE")"
        HOOKS_CHANGED=true
        ;;
    unchanged)
        log_ok "Settings unchanged: $(display_path "$SETTINGS_FILE")"
        ;;
    dry-run)
        log "[DRY RUN] Would merge settings"
        ;;
    error-corrupt)
        log_error "$(display_path "$SETTINGS_FILE") is corrupt. Use --force to overwrite."
        write_summary ERROR "claude hooks" "settings corrupt"
        ;;
    error-clobber)
        log_error "$(display_path "$SETTINGS_FILE") merge would lose fields. Use --force to proceed."
        write_summary ERROR "claude hooks" "merge would lose fields"
        ;;
    error-exit)
        log_error "$(display_path "$SETTINGS_FILE") hooks merge failed (node exit $merge_rc) -- see $(display_path "$LOG_FILE")"
        write_summary ERROR "claude hooks" "settings merge failed (exit $merge_rc)"
        ;;
    *)
        log_error "Unexpected merge result: $MERGE_RESULT"
        write_summary ERROR "claude hooks" "unexpected error"
        ;;
esac

# --- END hooks body (extracted by build-deploy) ---

# --- BEGIN exit (extracted by build-deploy) ---
if [ "$ERRORS" -gt 0 ]; then
    log "FAILED with $ERRORS error(s)" "error"
    exit 1
elif [ "$WARNINGS" -gt 0 ]; then
    log "COMPLETED with $WARNINGS warning(s)" "warn"
    exit 0
else
    log "COMPLETED successfully" "ok"
    exit 0
fi
# --- END exit (extracted by build-deploy) ---
