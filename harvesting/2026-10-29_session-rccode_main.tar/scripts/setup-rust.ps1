# setup-rust.ps1 — Installs/updates Rust toolchain (rustup + cargo) on Windows
# Safe to re-run — detects existing install and upgrades as needed.
#
# Windows: Uses winget to install rustup, which manages the Rust toolchain.
# Checks for MSVC Build Tools (required for linking) and warns if missing.
#
# See the /tool-registry skill (registries/tool-registry.json) for install source details.

# --- Shared library ---
. (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) "aitools-lib.ps1")
Initialize-Logging "setup-rust"

# --- OS guard ---
if ($PSVersionTable.PSVersion.Major -ge 6 -and -not $IsWindows) {
    LogError "This script is for Windows. On macOS/Linux, use the .sh version."
    exit 1
}

# --- Install/update ---
$cargoPath = Join-Path $env:USERPROFILE ".cargo\bin\cargo.exe"

if (Test-Path $cargoPath) {
    Log "rustup found -- updating toolchain..."
    $rustupExe = Join-Path $env:USERPROFILE ".cargo\bin\rustup.exe"
    $rustupOutput = & $rustupExe update 2>&1 | Out-String
    $updateRc = $LASTEXITCODE
    # Full output to the log as detail (C-F2); the exit code decides.
    foreach ($l in $rustupOutput.Split("`n")) {
        if ($l.Trim()) { LogDetail "rustup-update: $($l.TrimEnd())" }
    }
    if ($updateRc -ne 0) {
        LogError "rustup update failed (exit $updateRc) -- see $logFile"
        Write-Summary "ERROR" "rust/cargo" "rustup update failed (exit $updateRc)"
    } else {
        $cargoVersion = (& $cargoPath --version 2>&1)
        $rustcPath = Join-Path $env:USERPROFILE ".cargo\bin\rustc.exe"
        $rustcVersion = (& $rustcPath --version 2>&1)
        LogOk "cargo $cargoVersion"
        LogOk "rustc $rustcVersion"
        Write-Summary "OK" "rust/cargo" "$cargoVersion"
    }
} else {
    Log "Installing Rust toolchain via winget..."
    $wingetOutput = winget install -e --id Rustlang.Rustup --accept-package-agreements --accept-source-agreements 2>&1 | Out-String
    Log-WingetOutput $wingetOutput
    if ($LASTEXITCODE -ne 0) {
        LogError "winget install rustup failed (exit code $LASTEXITCODE)"
        Write-Summary "ERROR" "rust/cargo" "winget install failed (exit $LASTEXITCODE)"
    }
    Refresh-Path

    if (Test-Path $cargoPath) {
        $cargoVersion = (& $cargoPath --version 2>&1)
        $rustcPath = Join-Path $env:USERPROFILE ".cargo\bin\rustc.exe"
        $rustcVersion = (& $rustcPath --version 2>&1)
        LogOk "Rust toolchain installed"
        LogOk "cargo $cargoVersion"
        LogOk "rustc $rustcVersion"
        Write-Summary "OK" "rust/cargo" "$cargoVersion"
    } else {
        LogError "winget install completed but cargo not found at $cargoPath"
        Write-Summary "ERROR" "rust/cargo" "install failed (cargo not found)"
    }
}

# --- MSVC Build Tools check ---
# Rust on Windows requires MSVC Build Tools for linking.
# Check common install locations for VS Build Tools or Visual Studio with VC tools.
$vsWhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
$hasMSVC = $false
if (Test-Path $vsWhere) {
    # 2>$null: vswhere prints nothing on stdout when no install matches; stderr text
    # would make $vsInstalls non-empty and fake a match. Checked on the next line.
    $vsInstalls = & $vsWhere -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath 2>$null
    if ($vsInstalls) { $hasMSVC = $true }
}

if ($hasMSVC) {
    LogOk "MSVC Build Tools found"
} else {
    LogWarn "MSVC Build Tools not detected -- cargo build will fail without a C linker"
    LogWarn "Install: winget install Microsoft.VisualStudio.2022.BuildTools"
    LogWarn "  Then add workload: Desktop Development with C++"
    Write-Summary "WARN" "rust/cargo" "MSVC Build Tools not detected -- cargo build will fail without a C linker"
}

# --- Build tool prerequisites (NASM, CMake, etc.) ---
# These are not needed by Rust itself, but by commonly used crates (aws-lc-sys, etc.)
# Get-Command exempt: command-existence check with explicit fallback
$nasmCheck = Get-Command nasm -ErrorAction SilentlyContinue
if (-not $nasmCheck) {
    # NASM may be installed but not on session PATH (winget user-scope install).
    # Check known paths before declaring "not found" -- same paths used post-install.
    # Verified: 2026-03-12 (NASM 3.01, winget user-scope)
    $nasmKnownPaths = @(
        "$env:LOCALAPPDATA\bin\NASM\nasm.exe",
        "$env:ProgramFiles\NASM\nasm.exe",
        "${env:ProgramFiles(x86)}\NASM\nasm.exe"
    )
    foreach ($p in $nasmKnownPaths) {
        if (Test-Path $p) {
            $env:PATH = "$(Split-Path $p);$env:PATH"
            Log "nasm found at $p (added to session PATH)"
            $nasmCheck = Get-Command nasm -ErrorAction SilentlyContinue
            break
        }
    }
}
if ($nasmCheck) {
    # 2>$null: the version is parsed from stdout only; an empty result is checked below.
    $nasmVer = (nasm --version 2>$null)
    if ($nasmVer) { $nasmVer = ($nasmVer -split '\s+' | Select-Object -Index 2) }
    LogOk "NASM found ($nasmVer)"
} else {
    Log "NASM not found -- installing via winget (needed by crypto crates like aws-lc-sys)..."
    $wingetOutput = winget install -e --id NASM.NASM --accept-package-agreements --accept-source-agreements 2>&1 | Out-String
    Log-WingetOutput $wingetOutput
    if ($LASTEXITCODE -ne 0) {
        LogWarn "winget install NASM failed (exit $LASTEXITCODE)"
        Write-Summary "WARN" "rust/cargo" "NASM not installed -- some cargo builds will fail"
        Write-Summary "ACTION" "" "winget install NASM.NASM -- needed for aws-lc-sys crypto crates"
    } else {
        $nasmKnownPaths = @("$env:LOCALAPPDATA\bin\NASM\nasm.exe", "$env:ProgramFiles\NASM\nasm.exe", "${env:ProgramFiles(x86)}\NASM\nasm.exe")
        if (Ensure-ToolOnPath -ToolName "nasm" -KnownPaths $nasmKnownPaths) {
            LogOk "NASM installed and on PATH"
        } else {
            LogWarn "NASM installed but not found at known locations or PATH"
            Write-Summary "WARN" "rust/cargo" "NASM installed but not on PATH"
            Write-Summary "ACTION" "" "Restart terminal or check NASM install location"
        }
    }
}

# --- Verify PATH persistence ---
$cargoBinDir = Join-Path $env:USERPROFILE ".cargo\bin"
$persistentPath = [Environment]::GetEnvironmentVariable("Path", "User") + ";" + [Environment]::GetEnvironmentVariable("Path", "Machine")
if ($persistentPath -notlike "*$cargoBinDir*") {
    LogError "~/.cargo/bin not in persistent PATH: $cargoBinDir"
    Write-Summary "ERROR" "rust/cargo" "installed but not on PATH"
    LogWarn "Add $cargoBinDir to PATH -- tool not accessible to Claude Code"
    Write-Summary "ACTION" "" "Add $cargoBinDir to PATH -- cargo not accessible"
}

# --- Exit ---
if ($errors -gt 0) {
    Log "FAILED with $errors error(s). See log: $logFile" "error"
    exit 1
} elseif ($warnings -gt 0) {
    Log "COMPLETED with $warnings warning(s)" "warn"
    exit 0
} else {
    Log "COMPLETED successfully" "ok"
    exit 0
}
