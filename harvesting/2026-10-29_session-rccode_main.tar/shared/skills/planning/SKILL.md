---
name: planning
description: "Session and plan strategy for Claude Code sessions. Use when starting a planning session, deciding session scope, coordinating subagents, or managing context budgets. Covers batch sizing, session flow, subagent parallelization, and user collaboration patterns."
---

## Intent

**Purpose**: Equip the agent with session and plan strategy --
context budget management, session flow, batch sizing, subagent
coordination, and user collaboration patterns. **Scope**: Session
planning conventions and execution strategy only. NOT plan file
creation or content (that is the agent's deliverable). NOT plan
re-evaluation (see `/optimize-plan`). NOT session handoff (see
`/handoff`). NOT session resume (see `/aitool-resume`). **Audience**:
Any agent starting a planning session, deciding session scope,
coordinating subagents, or managing context budgets.

## Session Working Convention

### Context budget

Stop building at **60-70% context usage**. Reserve remaining for:
- Commit/push workflow
- Late-session course corrections
- Gap filing and release notes

Check `/context` periodically during long sessions.

### Context windows by model

| Model | Context Window | 10% injection budget |
|-------|---------------|---------------------|
| Opus (extended) | 1M tokens | 100k tokens ≈ 400k chars |
| Opus/Sonnet (standard) | 200k tokens | 20k tokens ≈ 80k chars |
| Haiku | ~100k tokens | 10k tokens ≈ 40k chars |

Subagents inherit the parent's model by default (`model: inherit`).
Override with `model: sonnet` etc. in skill/subagent frontmatter.

### Session flow

1. Read the plan + incidents.json + relevant rules
2. Work through implementation steps in order
3. Surface ambiguities as they arise (surfacing duty)
4. At 60-70%: stop building, file gaps, update release notes, commit,
   tag, push
5. If more work remains, note where to resume in the commit message

## Planning Patterns

### When to create a plan file

Create `plans/*.md` when work:
- Spans multiple sessions
- Has phased gates or dependencies
- Needs detailed design beyond a roadmap row
- Modifies 3+ code files or shared libraries

### Batch sizing

Break implementation into **2-3 file chunks** with verification between.
Large batches (10+ files) cause rule fade — cross-cutting concerns get
ignored even when rules are in context.

After each batch:
- Re-read the rules that apply to the next batch
- Run tests/checks
- Verify the completed batch doesn't break existing behavior

### Verbatim code vs pseudocode

- **Verbatim** (exact old_string/new_string): For production code, shared
  libraries, scripts with error-handling requirements
- **Pseudocode** (sketch the approach): Only for exploratory/design phases
  where the exact code depends on findings

Plans with pseudocode that'll need improvisation during implementation
produce more violations than plans with verbatim code.

### Foundational decisions

Every plan that resolves ambiguities should capture them in a
"Foundational Decisions" section — numbered, authoritative, not revisited
unless explicitly reopened.

## Subagent Coordination

### When to use subagents

- **Research tasks**: Exploring codebases, reading docs, searching for patterns
- **Parallel independent queries**: Multiple searches that don't depend on each other
- **Protecting context**: Heavy exploration output stays in the subagent, summary returns

### When NOT to use subagents

- Writing code in projects with cross-cutting rules (subagents don't inherit rules)
- Tasks that need the full conversation context
- Simple, directed searches (use Grep/Glob directly)

### Subagent context gap

Subagents do NOT inherit:
- Project rules (`.claude/rules/*.md`)
- Skills from parent conversation
- CLAUDE.md content

Mitigation: SubagentStart hook injects skills and governance context
via pre-built cache (when deployed). Until then, include critical rules
in the subagent prompt.

### Subagent file access restriction

Subagents cannot use Glob or Grep on paths outside the current repo.
The tools are permission-denied. The Read tool with explicit absolute
paths WORKS for cross-repo access.

When delegating tasks that need files from other repos (dotprofile
session archives, other project repos):
- Provide the FULL ABSOLUTE PATH in the delegation prompt
- Do NOT instruct the subagent to "search for" or "find" files
- Use `ls` via Bash to discover file lists from the main agent,
  then pass explicit paths to the subagent
- This restriction applies recursively — subagents of subagents
  have the same limitation

### Parallelization

Launch multiple subagents in a single message when queries are
independent. Use `run_in_background` for tasks you don't need results
from immediately.

Do NOT duplicate work — if you delegate research to a subagent, don't
also perform the same searches yourself.

### Delegation duty

Every delegation prompt carries seven elements: identity, rules,
skills, operational learning, the `WRITE_BLOCKED` signal, access
(explicit paths), and the name prefix -- the delegate writes every
`*.md` file with its name as a prefix (`S2-report.md`, decision
D-DEL1). Use the `/delegate` skill to write the prompt and to verify
what comes back.

When planning parallel or chained delegation, check the nesting cap
first: `CLAUDE_CODE_MAX_SUBAGENT_SPAWN_DEPTH` (documented default 3;
1 in the Claude Code web environment, where a subagent cannot
delegate further). Size each delegate's scope to what it can finish
without delegating.

## User Collaboration

### User as co-architect

During planning, actively involve the user:
- **Present options, not conclusions.** "Here are three approaches,
  which fits?" beats "I recommend X."
- **Flag uncertainty explicitly.** "I'm not sure about Y — what's your
  take?" instead of guessing.
- **Ask for domain knowledge.** The user has context that no amount of
  codebase exploration replaces.

### Clarify before complying

If a user response seems to contradict or reverse a prior recommendation,
ask: "Just to confirm — did you mean X or Y?" A quick clarification
avoids wasted work from miscommunication.

### Don't assume

When uncertain about a design decision, file it as an open question
or ask the user. "Probably" is ambiguous — mark it as a gap that needs
resolution, or ask.

### Suggest answers with questions

Never ask a bare question that blocks the user. Always pair the question
with a suggested answer, evaluated against these criteria:

1. **Current state** — what's built, broken, or in progress right now?
2. **Context** — what is the user working on? What have they said matters?
3. **Leverage** — which option unblocks the most downstream work?
4. **Risk** — which option is easiest to course-correct from if wrong?
5. **Precedent** — has a similar decision been made? What worked before?
6. **Ambiguity** — if not confident, say so. Present options with
   tradeoffs rather than picking one.

Format: "Should we do X? I'd suggest Y because [criteria 1, 3 apply].
Alternative Z if [different tradeoff]."

The user can accept, modify, or reject — but they're never stuck
waiting for you to have an opinion.
