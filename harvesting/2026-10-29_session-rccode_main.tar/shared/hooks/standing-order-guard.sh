#!/usr/bin/env bash
# standing-order-guard.sh — Claude Code PreToolUse hook
# Purpose: Enforce standing orders by inspecting Bash tool calls before
#   execution. Catches USO violations that would otherwise trigger
#   permission prompts or bypass dedicated tools.
# Scope: USO enforcement only (dedicated tools, scratch files, simple
#   bash commands). NOT agentic standards, NOT script-standards compliance.
# Audience: Claude Code PreToolUse hook system — fires on every Bash call.
#
# Enforces:
#   USO: Dedicated tools for file ops (Read/Edit/Write/, not Bash)
#   USO: Scratch files for complex scripting (no long inline commands)
#   USO: Simple Bash commands only (no &&, ||, ;, $(...), backticks, globs in rm)
#
# Hook contract:
#   - Receives JSON on stdin (tool_name, tool_input.command, etc.)
#   - Exit 0 = allow
#   - Exit 2 = block (stderr becomes Claude's feedback)
#   - Must never crash or hang (would break Claude Code)
#
# Rollout mode (per-check):
#   MODE_AND="enforce"       — && : zero false positives confirmed, blocking
#   MODE_SUBSHELL="enforce"  — $(): zero false positives confirmed, blocking
#   MODE_SCRATCH="enforce"   — scratch files: zero false positives confirmed, blocking
#   MODE_OR="enforce"        — || : zero false positives, promoted 2026-03-24
#   MODE_SEMICOLON="enforce" — ;  : pwsh/perl exemptions in place, promoted 2026-03-24
#   MODE_BACKTICK="enforce"  — backticks: zero false positives, promoted 2026-03-24
#   MODE_SED="enforce"       — sed outside a pipeline: the 2026-10-21 change
#                              (read-only `sed -n '<N[,M]>p' <file>` exemption,
#                              incident #82; single-line commands only) only
#                              narrowed what is blocked, so the check stays at
#                              enforce (commander, 2026-10-21)
#   See .claude/rules/hook-rollout.md for the observe-then-enforce practice.
#
# Design decisions:
#   - Pure-bash JSON parsing (jq not guaranteed in hook environment)
#   - Conservative matching: only flag clear violations, allow ambiguous cases
#   - Helpful feedback: tell Claude which tool to use instead
#   - Pipeline exemption: cat/head/tail in pipelines (cmd | ...) are allowed
#     because the Read tool cannot pipe output into other commands
#
# KPI definitions (emit to log, future: structured JSONL):
#   - guardFireCount: total hook invocations per session
#   - guardBlockCount: violations blocked (exit 2) per session
#   - guardObserveCount: violations observed but allowed per session
#   - falsePositiveRate: user-reported false positives / total blocks

set -euo pipefail

# --- Mode and logging ---
MODE_AND="enforce"       # &&  — zero false positives confirmed; blocking
MODE_SUBSHELL="enforce"  # $() — zero false positives confirmed; blocking
MODE_SCRATCH="enforce"   # scratch files — zero false positives confirmed; blocking
MODE_OR="enforce"        # ||  — zero false positives; promoted 2026-03-24
MODE_SEMICOLON="enforce" # ;   — pwsh/perl exemptions in place; promoted 2026-03-24
MODE_BACKTICK="enforce"  # backticks — zero false positives; promoted 2026-03-24
MODE_SED="enforce"       # sed — #82 sed -n exemption (2026-10-21) only narrowed matching; enforce

LOG_DIR="$HOME/.aitools/logs"
LOG_FILE="$LOG_DIR/standing-order-guard.log"

# Ensure log directory exists (needed for observe logging; harmless in enforce-only runs)
mkdir -p "$LOG_DIR"

# --- Telemetry: JSONL event emission ---
# Appends one structured line to the session event log (~0.1ms).
# Session dir resolved from .scratch/.current-session (set by scratch-init.sh).
# If unavailable, silently no-ops (hook must never fail).
_SESSION_DIR=""
_cs_file="$(git rev-parse --show-toplevel 2>/dev/null || echo "")/.scratch/.current-session"
if [ -f "$_cs_file" ]; then
    _SESSION_DIR=$(cat "$_cs_file" 2>/dev/null || true)
fi

emit_hook_event() {
    local event_type="$1" detail_json="$2"
    [ -n "$_SESSION_DIR" ] || return 0
    printf '{"t":"%s","type":"%s","src":"sog","d":%s}\n' \
        "$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
        "$event_type" "$detail_json" \
        >> "$_SESSION_DIR/events.jsonl" 2>/dev/null || true
}

# violation() — dispatch based on per-check mode
# $1: message  $2: mode variable value (enforce or observe; defaults to enforce)
# $3: check name (for telemetry)
# In enforce mode: write message to stderr, exit 2 (block)
# In observe mode: append to log file, exit 0 (allow)
violation() {
    local message="$1"
    local mode="${2:-enforce}"
    local check_name="${3:-unknown}"
    if [ "$mode" = "enforce" ]; then
        emit_hook_event "hook_block" "{\"check\":\"$check_name\"}"
        echo "$message" >&2
        exit 2
    else
        emit_hook_event "hook_warn" "{\"check\":\"$check_name\",\"mode\":\"observe\"}"
        printf '%s [WOULD-BLOCK] %s | cmd: %s\n' \
            "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$message" "$COMMAND" \
            >> "$LOG_FILE"
        exit 0
    fi
}

INPUT=$(cat)

# --- Pure-bash JSON field extraction ---
# Same pattern as session-archive.sh. Handles simple top-level string values.
# Uses bash regex (zero external process forks) since this is a hot-path hook.
json_field() {
    local json="$1" key="$2"
    local pattern="\"${key}\"[[:space:]]*:[[:space:]]*\"([^\"]*)\""
    if [[ "$json" =~ $pattern ]]; then
        printf '%s' "${BASH_REMATCH[1]}"
    fi
}

# Extract tool_input.command — it's nested, so we need the command field
# from within tool_input. Since our JSON parser is simple, we can grep for
# the "command" key directly (it appears at the tool_input level).
COMMAND=$(json_field "$INPUT" "command")

# If no command found (shouldn't happen for Bash tool), allow
if [ -z "$COMMAND" ]; then
    exit 0
fi

# --- Full command extraction (escape-aware) ---
# json_field() stops at the first escaped quote (\"), which hides everything
# after it — including newlines — when a command's lines contain quotes
# (e.g. echo "x"). The multi-line check below needs the WHOLE command, so
# extract it honoring backslash escapes: a JSON string value is a run of
# (escaped char \X) or (any char that is not a quote or backslash).
# Only the newline check uses this; the operator checks keep using COMMAND so
# their matching behavior (and false-positive profile) is unchanged.
json_field_full() {
    local json="$1" key="$2"
    local pattern="\"${key}\"[[:space:]]*:[[:space:]]*\"((\\\\.|[^\"\\\\])*)\""
    if [[ "$json" =~ $pattern ]]; then
        printf '%s' "${BASH_REMATCH[1]}"
    fi
}
COMMAND_FULL=$(json_field_full "$INPUT" "command")
[ -n "$COMMAND_FULL" ] || COMMAND_FULL="$COMMAND"

# --- USO: Scratch files for complex scripting ---
# In JSON, newlines in strings are escaped as \n (literal two-char sequence).
# Count occurrences by measuring string length before/after removing \n sequences.
# This avoids grep exit-code issues with set -euo pipefail when no matches exist.

# literal "\n" tokens (raw JSON form)
STRIPPED_LIT="${COMMAND_FULL//\\n/}"
LIT_COUNT=$(( (${#COMMAND_FULL} - ${#STRIPPED_LIT}) / 2 ))

# real newline characters (decoded form)
NL=$'\n'
STRIPPED_REAL="${COMMAND_FULL//$NL/}"
REAL_COUNT=$(( ${#COMMAND_FULL} - ${#STRIPPED_REAL} ))

NEWLINE_COUNT=$(( LIT_COUNT + REAL_COUNT ))

# 4+ lines (3+ newlines) = too complex for inline. Write a temp file instead.
if [ "$NEWLINE_COUNT" -ge 3 ]; then
    LINE_COUNT=$((NEWLINE_COUNT + 1))
    violation "USO: Scratch files --: This command is ~${LINE_COUNT} lines long. Write it to a temp .sh or .ps1 file using the Write tool, execute with Bash, then clean up. USO: never inline long commands in the Bash tool." "$MODE_SCRATCH" "scratch"
fi

# --- USO: Simple Bash commands only ---
# Block compound operators and command substitution that trigger permission prompts.
# Pipelines (|) are explicitly OK per the USO.
# Checked before the first-token allowlist because compound commands like
# `git tag && git push` have `git` as first token and would exit early.
# $() and backtick checks use raw INPUT (not COMMAND) because json_field
# truncates at \" — $(...) inside quoted arguments would be invisible.
case "$COMMAND" in
    *'&&'*) violation "USO: Simple Bash commands only --: Don't use '&&' to chain commands. Make separate Bash tool calls instead. For git in another repo, use 'git -C /path' instead of 'cd /path && git'." "$MODE_AND" "and" ;;
    *'||'*) violation "USO: Simple Bash commands only --: Don't use '||' to chain commands. Make separate Bash tool calls instead." "$MODE_OR" "or" ;;
    *';'*)
        # Exempt ; inside scripting-language arguments: pwsh -Command '...;...' and perl '...;...'
        # The ; is a language-internal statement separator, not a shell command separator.
        # perl: any invocation (perl -ne, -pe, -e, -E, etc.) may contain Perl semicolons.
        case "$COMMAND" in
            pwsh\ *|powershell\ *|perl\ *) ;;
            *) violation "USO: Simple Bash commands only --: Don't use ';' to chain commands. Make separate Bash tool calls instead." "$MODE_SEMICOLON" "semicolon" ;;
        esac
        ;;
esac
case "$INPUT" in
    *'$('*) violation "USO: Simple Bash commands only --: Don't use '\$(...)' command substitution. For commit messages, write to a temp file with Write and use 'git commit -F'. For other values, compute in a prior step." "$MODE_SUBSHELL" "subshell" ;;
    *'`'*)  violation "USO: Simple Bash commands only --: Don't use backtick command substitution. For commit messages, write to a temp file with Write and use 'git commit -F'. For other values, compute in a prior step." "$MODE_BACKTICK" "backtick" ;;
esac

# --- USO: Dedicated tools for file operations ---
# Pattern: command starts with a file-op utility that has a dedicated tool.
# We check the first token of the command (before any arguments).
read -r FIRST_TOKEN _ <<< "$COMMAND"

# Allowlist: commands that look like file ops but are legitimate shell use.
# pwsh wrapping, perl, uv, git operations, npm/node, etc. are always OK.
case "$FIRST_TOKEN" in
    pwsh|powershell|git|perl|uv|npm|node|python*|pip*|cargo|rustup|brew|winget|choco)
        exit 0
        ;;
esac

# --- USO: Simple Bash commands only (glob in destructive operations) ---
# Glob patterns in rm can expand unexpectedly. Write a cleanup script instead.
case "$FIRST_TOKEN" in
    rm)
        case "$COMMAND" in
            *'*'*|*'?'*)
                violation "USO: Simple Bash commands only --: Don't use glob patterns (*, ?) with 'rm'. Write a cleanup script listing the specific files, execute it, then clean up the script." "enforce" "glob-rm"
                ;;
        esac
        ;;
esac

# Check for standalone file-reading commands (should use Read tool)
# Allow in pipelines (cmd | ...) — Read tool can't pipe output into other commands.
case "$FIRST_TOKEN" in
    cat)
        case "$COMMAND" in
            *\|*) ;;  # Pipeline — legitimate shell use
            *) violation "USO: Dedicated tools --: Use the Read tool instead of 'cat' to read files. The Read tool provides line numbers and handles large files better." "enforce" "cat" ;;
        esac
        ;;
    head)
        case "$COMMAND" in
            *\|*) ;;
            *) violation "USO: Dedicated tools --: Use the Read tool with offset/limit parameters instead of 'head'. Example: Read with limit=20 for the first 20 lines." "enforce" "head" ;;
        esac
        ;;
    tail)
        case "$COMMAND" in
            *\|*) ;;
            *) violation "USO: Dedicated tools --: Use the Read tool with offset parameter instead of 'tail'. Example: Read with offset=100 to start from line 100." "enforce" "tail" ;;
        esac
        ;;
esac

# grep/find/glob/ls checks removed 2026-06-21.
# Per Claude Code 2.1.117 the Grep and Glob tools are no longer available on
# macOS/Linux (https://x.com/dmwlff/status/2047105823890166170), so steering
# grep/find toward those tools is no longer valid. ls was always allowed (gray
# area — commonly used for quick verification). These commands now fall through
# to the final allow at the end of the script.
#
# NOTE: the previous half-commented version left a dangling `exit 0` + `;;`
# here, which (a) was a syntax error caught only because the unconditional
# `exit 0` short-circuited execution before the parser reached `;;`, and
# (b) made the sed/awk/echo-redirect checks below dead code. Both are fixed by
# removing the block entirely.

# Check for file-editing commands (should use Edit tool)
# Allow in pipelines — Edit tool can't pipe output into other commands.
# Read-only exemption (incident #82): `sed -n '<addr>p' <file>...` prints lines
# and modifies nothing. Matched narrowly so no write form slips through: the
# script must be a single line address or range (N, N,M, N,$, $) followed by p,
# optionally single-quoted; every later argument must not start with '-' (no
# -i / --in-place after the script) and no argument may contain < > | ; & (no
# redirection). `w`, `e`, `s///w`, multiple -e scripts and -i all fall through
# to the check. Commands that use \" are truncated by json_field and fall
# through too (conservative). The exemption applies only to single-line
# commands (NEWLINE_COUNT 0, counted on the escape-aware COMMAND_FULL): the
# checks above look only at the first token, so a second line could otherwise
# carry a write form (2026-10-21, a narrowing change; MODE_SED stays enforce).
_sq="'"
SED_READONLY_RE="^sed[[:space:]]+-n[[:space:]]+${_sq}?([0-9]+|[$])(,([0-9]+|[$]))?p${_sq}?([[:space:]]+[^-[:space:]<>|;&${_sq}][^[:space:]<>|;&]*)+[[:space:]]*$"
case "$FIRST_TOKEN" in
    sed)
        case "$COMMAND" in
            *\|*) ;;  # Pipeline — legitimate shell use
            *)
                if [ "$NEWLINE_COUNT" -eq 0 ] && [[ "$COMMAND" =~ $SED_READONLY_RE ]]; then
                    :  # read-only line print (#82), single-line command only — allowed
                else
                    violation "USO: Dedicated tools --: Use the Edit tool instead of 'sed' to modify files. For non-trivial string manipulation, use Perl (USO: Perl for string manipulation). Read-only line prints (sed -n 'N,Mp' file) are allowed; the Read tool with offset/limit is preferred." "$MODE_SED" "sed"
                fi
                ;;
        esac
        ;;
    awk)
        case "$COMMAND" in
            *\|*) ;;  # Pipeline — legitimate shell use
            *) violation "USO: Dedicated tools --: Use the Read tool instead of 'awk' to process files. For string manipulation, use Perl (USO: Perl for string manipulation)." "enforce" "awk" ;;
        esac
        ;;
esac

# Check for file-writing patterns (should use Write tool)
# These are harder to detect by first token alone. Check the full first line
# for redirection patterns that indicate file creation.
FIRST_LINE=$(printf '%s' "$COMMAND" | head -1)
case "$FIRST_LINE" in
    echo*\>*|printf*\>*)
        # echo/printf redirecting to a file
        violation "USO: Dedicated tools --: Use the Write tool instead of echo/printf redirection to create files. The Write tool handles encoding and permissions correctly." "enforce" "echo-redirect"
        ;;
esac

# All checks passed — allow the command
emit_hook_event "hook_fire" "{\"result\":\"allow\"}"
exit 0