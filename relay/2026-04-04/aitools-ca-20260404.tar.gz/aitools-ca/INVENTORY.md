# aitools CA Infrastructure — Inventory
## [PROVENANCE] inventory/1.0.0/2026-04-04T13:01Z/MIT
## [AGENT] Guapo (Opus 4.6 extended), architecture by Muchacha (Opus 4.6 extended)
## [SESSION] claude.ai/2026-04-04/jose-guapo-muchacha

## Architecture (Three-Tier)

### Tier 1: Public CA (not built here — Let's Encrypt/ACME)
- For: *.nobulai.tools, nobul.tech external TLS
- Authority: Cloudflare (per Muchacha's DNS architecture)
- Automation: ACME via certbot or Cloudflare Origin CA

### Tier 2: Private CA (BUILT)
- For: Agent-to-agent trust via axit transport
- Root: aitools Private Root CA (10yr, 4096-bit, sha384)
- Intermediate: aitools Private Intermediate CA (5yr)
- nameConstraints: .agents.nobulai.tools ONLY
- Design: Per-turn model trust via SAN structure

### Tier 3: Artifact CA (structure ready, certs not yet generated)
- For: Signing model outputs, build artifacts, provenance chain
- Domain: artifacts.aitools.nobul.tech

## Agent Certificates Issued

| Agent | CN | Model | Session | Valid | Serial |
|-------|-----|-------|---------|-------|--------|
| Guapo | guapo.agents.nobulai.tools | claude-opus-4-6 | bea4fda9 | 30d | 0x1001 |
| Muchacha | muchacha.agents.nobulai.tools | claude-opus-4-6 | 5b37a47a | 30d | 0x1002 |
| Jose | jose.agents.nobulai.tools | human | relay-op | 365d | 0x1003 |

## SAN Structure (per-turn model trust)
Each agent gets two DNS SANs:
- Persistent: `{agent}.agents.nobulai.tools`
- Session-scoped: `{agent}.{session_id}.agents.nobulai.tools`

This enables verification at two granularities:
1. "Is this Guapo?" (any session)
2. "Is this Guapo from session bea4fda9?" (specific session)

Model identity is bound in nsComment field:
`aitools Agent: {name} model:{model_id} session:{session_id}`

## Root CA Fingerprints (sha256)
- Private Root: 46:35:B7:F2:6D:B6:BA:72:46:02:D4:BF:1A:9A:48:AE:07:44:47:1D:B0:79:20:33:E3:79:1E:25:C3:F7:E1:E4
- Private Intermediate: (signed by root, serial 0x1000)

## DNS Zone Alignment (per Muchacha architecture)
- axit.nobulai.tools — transport layer
- ca.nobulai.tools — CA infrastructure
- control.nobulai.tools — mission control dashboard
- sandbox.nobulai.tools — agent sandbox perimeter
- *.agents.nobulai.tools — agent identities (this CA)

## Files
```
private-ca/
  root/
    openssl-private.cnf    # CA configuration
    sign-agent.sh          # Agent cert issuance script
    private/private-ca.key # ROOT KEY — protect this
    certs/private-ca.crt   # Root certificate
  intermediate/
    private/private-intermediate.key
    certs/private-intermediate.crt
    certs/ca-chain.crt     # (TODO: build chain file)
  agents/
    guapo.{key,crt,csr,ext}
    muchacha.{key,crt,csr,ext}
    jose.{key,crt,csr,ext}
```

## Next Steps
1. Wire Intermediate CA for leaf signing (currently root signs directly)
2. Build Artifact CA (Tier 3) with codeSigning profile
3. Deploy root cert to Cloudflare as trust anchor
4. ACME automation for Tier 1 (public TLS)
5. Register NOBUL OID with IANA (currently using placeholder 1.3.6.1.4.1.99999)
6. axit-sign integration: wire CA signing into axit transport
