#!/bin/sh
# sign-agent.sh — Issue an agent certificate from the private CA
# [PROVENANCE] sign-agent/1.0.0/2026-04-04T13:00Z/MIT
# [AGENT] Guapo (Opus 4.6 extended)
#
# Usage: ./sign-agent.sh <agent_name> <model_id> <session_id> [days]
# Example: ./sign-agent.sh guapo "claude-opus-4-6" "bea4fda9" 30

set -e

AGENT_NAME="$1"
MODEL_ID="$2"
SESSION_ID="$3"
DAYS="${4:-30}"

if [ -z "$AGENT_NAME" ] || [ -z "$MODEL_ID" ] || [ -z "$SESSION_ID" ]; then
  echo "Usage: $0 <agent_name> <model_id> <session_id> [days]"
  echo "  agent_name:  e.g. guapo, muchacha, jose"
  echo "  model_id:    e.g. claude-opus-4-6, human, deepseek-r1"
  echo "  session_id:  first 8 chars of session UUID"
  echo "  days:        cert validity (default: 30)"
  exit 1
fi

CA_DIR="$(cd "$(dirname "$0")" && pwd)"
AGENT_DIR="$CA_DIR/../agents"
FQDN="${AGENT_NAME}.agents.nobulai.tools"
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

echo "=== aitools Agent Certificate Issuance ==="
echo "Agent:     $AGENT_NAME"
echo "FQDN:      $FQDN"
echo "Model:     $MODEL_ID"
echo "Session:   $SESSION_ID"
echo "Valid:     $DAYS days"
echo "Issued:    $TIMESTAMP"
echo ""

# Generate agent key (2048 for leaf certs - balance security/performance)
openssl genrsa -out "$AGENT_DIR/${AGENT_NAME}.key" 2048 2>/dev/null
chmod 400 "$AGENT_DIR/${AGENT_NAME}.key"

# Create SAN + custom extensions file for this agent
cat > "$AGENT_DIR/${AGENT_NAME}.ext" << EXTEOF
basicConstraints = CA:FALSE
nsComment = "aitools Agent: $AGENT_NAME model:$MODEL_ID session:$SESSION_ID"
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid,issuer
keyUsage = critical, nonRepudiation, digitalSignature, keyEncipherment
extendedKeyUsage = clientAuth
subjectAltName = DNS:$FQDN,DNS:${AGENT_NAME}.${SESSION_ID}.agents.nobulai.tools
# Custom: model binding in certificate (human-readable in nsComment above,
# machine-readable via SAN structure: <agent>.<session>.agents.nobulai.tools)
EXTEOF

# Generate CSR
openssl req -new -sha384 \
  -key "$AGENT_DIR/${AGENT_NAME}.key" \
  -subj "/C=US/ST=California/O=NOBUL Technology/OU=aitools-agents/CN=$FQDN" \
  -out "$AGENT_DIR/${AGENT_NAME}.csr" 2>/dev/null

# Sign with Intermediate CA (use root for now until intermediate signing is wired)
openssl ca -config "$CA_DIR/openssl-private.cnf" \
  -extfile "$AGENT_DIR/${AGENT_NAME}.ext" \
  -days "$DAYS" -notext -md sha384 -batch \
  -policy policy_agent \
  -in "$AGENT_DIR/${AGENT_NAME}.csr" \
  -out "$AGENT_DIR/${AGENT_NAME}.crt" 2>&1

echo ""
echo "=== Certificate Issued ==="
openssl x509 -noout -subject -issuer -dates -in "$AGENT_DIR/${AGENT_NAME}.crt"
echo ""
echo "SANs:"
openssl x509 -noout -text -in "$AGENT_DIR/${AGENT_NAME}.crt" | grep -A2 "Subject Alternative Name"
echo ""
echo "nsComment:"
openssl x509 -noout -text -in "$AGENT_DIR/${AGENT_NAME}.crt" | grep "nsComment"
echo ""
openssl x509 -noout -fingerprint -sha256 -in "$AGENT_DIR/${AGENT_NAME}.crt"
echo "Timestamp: $TIMESTAMP"
